return function(mod)
 local Layout=require('src.core.game3.layout_native')
 local Tiles=require('src.core.game3.tileset_native')
 local Interactions=require('src.core.game3.scripting.interaction_scripts')
 local Space=require('src.core.game3.scripting.space')
 local Objects=require('src.core.game3.objects')
 local Sprites=require('src.core.game3.ow_sprites')
 local Pokemon=require('src.core.game3.pokemon')
 local Encounters=require('src.core.game3.encounters')
 local World=assert(loadstring(assert(mod:read('assets/slateport/world.lua'))))()
 local S={CITY='FR_HOENN_SLATEPORT_CITY',HARBOR='FR_HOENN_SLATEPORT_DOCK',world=World}
 local atlases,draws={},{}
 local ready,get=Tiles.ready,Tiles.get
 Tiles.ready=function(pair)if type(pair)=='string' and World.maps[pair:match('^hoenn_(.+)$')]then return true end;return ready(pair)end
 Tiles.get=function(pair)
  local spec=type(pair)=='string' and World.maps[pair:match('^hoenn_(.+)$')]
  if not spec then return get(pair) end
  if not atlases[pair] then
   local name=pair:sub(7);local d=spec.data;if not d then return nil end
   local img=mod.assets:image('assets/slateport/'..name..'-under.png')
   local over=mod.assets:image('assets/slateport/'..name..'-over.png')
   img:setFilter('nearest','nearest');over:setFilter('nearest','nearest')
   local ts={pair=pair,image=img,overImage=over,layered=true,cols=16,rows=img:getHeight()/16,quads={},overQuads={},midToSlot={}}
   for i,mid in ipairs(d.mids)do ts.midToSlot[mid]=i-1 end
   atlases[pair]=ts
  end
  return atlases[pair]
 end
 local resolve=Space.resolveObjectGraphicsId
 Space.resolveObjectGraphicsId=function(obj,neighbor)
  if obj and World.sprites[obj.graphicsId] and tostring(obj.scriptKey):match('^__HOENN_')then return obj.graphicsId end
  return resolve(obj,neighbor)
 end
 local getDraw=Sprites.getDraw
 Sprites.getDraw=function(id)
  local s=World.sprites[id];if not s then return getDraw(id)end
  if not draws[id]then
   local im=mod.assets:image(s.file);im:setFilter('nearest','nearest')
   local d={image=im,width=s.width,height=s.height,frameCount=s.frames,quads={}}
   for i=0,s.frames-1 do d.quads[i]=love.graphics.newQuad(i*s.width,0,s.width,s.height,im:getDimensions())end
   draws[id]=d
  end
  return draws[id]
 end
 -- Neighbor pools hide native variable graphics IDs >=240. These private
 -- static sprites must remain visible on connected maps, including Route 110.
 local spawn=Objects.spawnFromDefs
 Objects.spawnFromDefs=function(defs,def,id)
  local pool=spawn(defs,def,id)
  if tostring(id):match('^FR_HOENN_')then
   for _,o in pairs(pool.byId)do if World.sprites[o.graphicsId]then o.invisible=false end end
  end
  return pool
 end
 local function installEncounters()
  for id,t in pairs(World.encounters)do
   local out={}
   for kind,a in pairs(t)do
    out[kind]={rate=a.rate,slots={}}
    for _,m in ipairs(a.slots)do
     local sp=assert(Pokemon.speciesFromName(m.species),'Unknown Hoenn species '..m.species)
     out[kind].slots[#out[kind].slots+1]={species=sp,minLevel=m.minLevel,maxLevel=m.maxLevel}
    end
   end
   Encounters._tables[id]=out
  end
 end
 local loadEncounters=Encounters.loadFromMod
 Encounters.loadFromMod=function(...)local r=loadEncounters(...);installEncounters();return r end
 local function behavior(b)
  if b==2 or b==3 then return 2 end
  if b>=0x10 and b<=0x15 then return 0x10 end
  if b>=0x30 and b<=0x3b then return b end
  if b==0x80 or b==0x83 then return b end
  return 0
 end
 function S.install(game)
  if not(game and game.data and game.data.maps)then return end
  local maps=game.data.maps
  for name,spec in pairs(World.maps)do
   if not spec.data then spec.data=assert(loadstring(assert(mod:read('assets/slateport/'..name..'.lua'))))()end
   if not maps[spec.id]then
    local d=spec.data;local cells={};local behaviors={}
    for mid,b in pairs(d.behaviors)do behaviors[mid]=behavior(b)end
    for i,v in ipairs(d.words)do
     local mid=v%1024;local block=math.floor(v/1024)%4;local elev=math.floor(v/4096);local b=behaviors[mid]
     local coll=block~=0 and 7 or b==2 and 0x18 or b==0x10 and 0x29 or 0
     if b==0x80 then coll=0x90 elseif b==0x83 then coll=0x93 elseif b>=0x38 and b<=0x3b then coll=0xa0+b-0x38 end
     cells[i]={mid=mid,coll=coll,elev=elev}
    end
    local pair='hoenn_'..name;Interactions.behaviors[pair]=behaviors
    local def={id=spec.id,name=spec.name,width=d.width,height=d.height,pair=pair,native=true,
     mapType=spec.outdoor and (name=='city' and 1 or 3) or 8,kind=spec.outdoor and 'route' or 'indoor',environment=spec.outdoor and 'ROUTE' or 'BUILDING',music=20000+spec.music,
     weather=0,bikingAllowed=0,allowRunning=1,showMapName=0,connections=spec.connections,warps={},objects={},coordEvents={},bgEvents={},mapScripts={},
     midLayout=Layout.fromDecoded({width=d.width,height=d.height,cells=cells,borderWidth=2,borderHeight=2,borderMids=d.border},spec.id,pair)}
    -- Retain original warp slot numbers. Unimplemented exits are solid.
    for i,w in ipairs(spec.warps)do
     local cell=def.midLayout:cellAt(w.x,w.y)
     def.warps[i]={x=w.x,y=w.y,elevation=w.elevation,destMap=w.destMap or spec.id,destWarp=w.destWarp}
     if w.disabled then if cell then cell.coll=7 end;def.warps[i].x=-100-i
     else
      local raw=d.behaviors[cell.mid];local door=spec.outdoor or raw==0x69
      cell.coll=door and 0x71 or 0x70;behaviors[cell.mid]=door and 0x60 or 0x65
      if raw==0x61 or raw==0x6a or raw==0x6b then cell.coll=0x70;behaviors[cell.mid]=0x66 end
     end
    end
    for _,row in ipairs(spec.objects)do
     local o={};for k,v in pairs(row)do o[k]=v end
     if o.trainer then o.trainerType=1;o.sight=o.sight or 3 end
     def.objects[#def.objects+1]=o
    end
    if name=='harbor'then def.objects[#def.objects+1]={localId=252,x=8,y=11,elevation=3,graphicsId=62,movementType=8,scriptKey='__HOENN_RETURN__'}end
    if spec.outdoor then
     for x=0,d.width-1 do
      if not spec.connections.north then def.midLayout:cellAt(x,0).coll=7 end
      if not spec.connections.south then def.midLayout:cellAt(x,d.height-1).coll=7 end
     end
     for y=0,d.height-1 do
      if not spec.connections.west then def.midLayout:cellAt(0,y).coll=7 end
      if not spec.connections.east then def.midLayout:cellAt(d.width-1,y).coll=7 end
     end
    end
    maps[spec.id]=def
   end
  end
  if Pokemon.ready()then installEncounters()end
 end
 assert(loadstring(assert(mod:read('hoenn_services.lua'))))()(mod,S)
 assert(loadstring(assert(mod:read('hoenn_music.lua'))))()(mod,World)
 assert(loadstring(assert(mod:read('debug_warp.lua'))))()(mod,S)
 return S
end
