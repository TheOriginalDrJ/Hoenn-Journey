-- Development shortcut: no ticket, story flag, or party changes.
return function(mod,Slateport)
 local Menu=require('src.ui.game3.start_menu')
 local Runtime=require('src.core.game3.runtime')
 local Warp=require('src.core.game3.warp')
 local show=Menu.show
 Menu.show=function(opts)
  local result=show(opts)
  local game=(opts and opts.game)or Runtime._game
  local session=(opts and opts.session)or Runtime.getSession()
  -- Do not bypass Safari/link-room session rules.
  if not game or not session or not Menu.saveOffered(session,game)then return result end
  for _,entry in ipairs(Menu.ENTRIES)do if entry.id=='hoenn_debug_warp'then return result end end
  local at=#Menu.ENTRIES+1
  for i,entry in ipairs(Menu.ENTRIES)do if entry.id=='exit'then at=i;break end end
  table.insert(Menu.ENTRIES,at,{id='hoenn_debug_warp',label='WARP',onSelect=function()
   Menu.close(true)
   Slateport.install(game)
   local ok,err=Warp.request(nil,game,Slateport.HARBOR,8,12,'down')
   if not ok then
    mod.log:warn('Hoenn debug warp failed: '..tostring(err))
    require('src.ui.game3.message').show('Could not warp to Slateport: '..tostring(err))
   end
  end})
  return result
 end
end
