return function(mod,S)
 local Runtime=require('src.core.game3.runtime')
 local Map=require('src.core.game3.map')
 local Field=require('src.core.game3.field')
 local Objects=require('src.core.game3.objects')
 local Space=require('src.core.game3.scripting.space')
 local Message=require('src.ui.game3.message')
 local Choice=require('src.ui.game3.choice')
 local Party=require('src.core.game3.party')
 local Pokemon=require('src.core.game3.pokemon')
 local Bridge=require('src.core.game3.battle_bridge')
 local Sight=require('src.core.game3.trainer_sight')
 local Trainers=require('src.core.game3.scripting.trainers')
 -- 1025Dex 1.1.28 explicitly supports exact encounters. Keep authored Hoenn
 -- tables while leaving its WILD GENS replacement policy untouched in Kanto.
 local startBattle=Bridge.start
 Bridge.start=function(owner,game,foe,opts)
  if opts and opts.wild and tostring(Map.current):match('^FR_HOENN_')then
   local copy={};for k,v in pairs(opts)do copy[k]=v end
   copy.__completeDexExact=true;opts=copy
  end
  return startBattle(owner,game,foe,opts)
 end
 local records,ids,keys={},{},{}
 for key in pairs(S.world.trainers)do keys[#keys+1]=key end;table.sort(keys)
 for i,key in ipairs(keys)do ids[key]=61000+i end
 local getTrainer=Trainers.get
 Trainers.get=function(id)return records[tonumber(id)]or getTrainer(id)end
 local function state()
  local s=Runtime.getSession();s.meta=s.meta or {};s.meta.hoennJourneyFireRed=s.meta.hoennJourneyFireRed or {}
  local st=s.meta.hoennJourneyFireRed;st.trainers=st.trainers or {};return st,s
 end
 local function say(text,done)
  Field.lock();Message.show(text,function()Field.unlock();if done then done()end end)
 end
 local function battle(row)
  local st,s=state();local tr=S.world.trainers[row.trainer]
  if st.trainers[tr.key]then say(tr.defeat~='' and tr.defeat or 'That was a good battle!');return true end
  if tr.double and Party.monsStateToDoubles(s.party)~=Party.PLAYER_HAS_TWO_USABLE_MONS then say('Bring two healthy Pokemon for our double battle!');return true end
  say(tr.intro~='' and tr.intro or tr.name..' would like to battle!',function()
   local pack=Trainers.pack();local class,pic=0,0
   local want=tr.className:gsub('_',''):upper()
   local aliases={COLLECTOR='SUPERNERD',TRIATHLETE='BIRDKEEPER',POKEFAN='GENTLEMAN',AROMALADY='BEAUTY',GUITARIST='ROCKER'}
   want=aliases[want]or want
   for _,t in pairs(pack and pack.trainers or {})do
    local cn=t.className or (pack.classNames and pack.classNames[t.class])or ''
    if cn:upper():gsub('[^A-Z]','')==want then class=t.class;pic=t.pic;break end
   end
   local party={}
   for _,m in ipairs(tr.party)do party[#party+1]={species=assert(Pokemon.speciesFromName(m.species)),level=m.level,rawIv=m.rawIv,iv=math.floor(m.rawIv*31/255),moves=m.moves}end
   local tid=ids[tr.key]
   records[tid]={id=tid,class=class,className=tr.className:gsub('_',' '),name=tr.name,pic=pic,gender=0,encounterMusic=0,doubleBattle=tr.double,partySize=#party,lastLevel=party[#party].level,aiFlags=1,items={},party=party,dialogs={intro=tr.intro,defeat=tr.defeat}}
   local foe=assert(Trainers.foeFromId(tid))
   local ok,err=Bridge.start(nil,Runtime._game,foe,{trainerId=tid,trainerName=tr.name,trainerPicId=pic,defeatText=tr.defeat,done=function(result)
    if result=='win'then st.trainers[tr.key]=true end
    Objects.unfreeze(row.localId);Field.unlock()
   end})
   if not ok then say('The battle could not start: '..tostring(err))end
  end)
  return true
 end
 function S.talk(row)
  if row.trainer then return battle(row)end
  if row.service=='heal'then
   say('Welcome to the Pokemon Center! Shall we restore your Pokemon?',function()
    Field.lock();Choice.yesNo(function(yes)
     Field.unlock();if not yes then return end
     local _,s=state();Party.healAll(s.party)
     Field.setHealPoint('FR_HOENN_SLATEPORT_CITY_POKEMON_CENTER_1F',7,4)
     s.healHealerLocalId=row.localId
     say('Your Pokemon are fully healed. We hope to see you again!')
    end)
   end);return true
  end
  if row.service=='shop'then
   -- Numeric FireRed IDs resolve ROM prices; host-name aliases omit price.
   Field.lock();require('src.ui.game3.shop_menu').show({session=Runtime.getSession(),items=row.stock or {4,3,22,14,18,17,85,86},onClose=function()Field.unlock()end});return true
  end
  say(row.dialogue);return true
 end
 local overworld=require('src.world.OverworldController');local talk=overworld.talkTo
 overworld.talkTo=function(ow,npc)
  if tostring(Map.current):match('^FR_HOENN_')and npc and npc.def and tostring(npc.def.scriptKey):match('^__HOENN_NPC__')then
   Objects.facePlayer(npc.localId,Runtime._game);return S.talk(npc.def)
  end
  return talk(ow,npc)
 end
 local start=Space.startScript
 Space.startScript=function(key,lid,...)
  if tostring(Map.current):match('^FR_HOENN_')and tostring(key):match('^__HOENN_NPC__')then
   local npc=Objects._byId[lid];if npc then Objects.unfreeze(lid);return S.talk(npc.def)end
  end
  return start(key,lid,...)
 end
 local defeated=Sight.isDefeated
 Sight.isDefeated=function(eo,...)
  if eo and eo.def and eo.def.trainer then return state().trainers[eo.def.trainer]==true end
  return defeated(eo,...)
 end
 local battleType=Sight.battleType
 Sight.battleType=function(eo)
  if eo and eo.def and eo.def.trainer then return S.world.trainers[eo.def.trainer].double and 4 or 0 end
  return battleType(eo)
 end
end
