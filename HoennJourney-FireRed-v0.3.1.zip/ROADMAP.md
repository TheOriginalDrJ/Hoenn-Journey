# Hoenn Journey implementation roadmap

Build the world and its gameplay systems first; author the new post-FireRed story afterward.

## Foundation delivered in 0.3.0

- Existing post-League Birch ticket and Vermilion/Slateport return ferry.
- Data-driven Emerald map importer, layered tiles, static NPC sprites, warp graph.
- Slateport city, harbor, houses, Mart, Center, fan club, museum and shipyard.
- Route 110, gatehouses, original encounter slots and fourteen trainer teams.
- Native FireRed battle/shop/healing interfaces, separate Hoenn trainer save records.
- External 1025Dex dependency; no duplicate species registry or battle-art payload.

## Next world-building passes

1. Finish Slateport interactions: signs/exhibits, name rater, NPC movement,
   remaining shops/gifts, original item pickups, and cycling-road behavior.
2. Add Mauville and Routes 103/109/111/117 with interiors, safe travel,
   encounters, trainer parties, music, and save/blackout regression tests.
3. Extend region-by-region to all Hoenn towns, routes, caves and dungeons.
   Add each map's interiors/events with the map, not as disconnected scenery.
4. Add gyms, badges/progression, field-move gates, optional areas, legendaries,
   challenge facilities, and the Hoenn League without overwriting Kanto flags.
5. Author the new post-FireRed story, level curve and quest state only after
   the complete region's travel/battle/services foundation is stable.

## Release gates

Every batch needs verified two-way exits, encounter/species resolution,
trainer outcomes, save/Continue, blackout recovery, music restoration, and
native-engine screenshots. Final shared release additionally needs a full
launcher test with 1025Dex and representative existing saves/mod profiles.
