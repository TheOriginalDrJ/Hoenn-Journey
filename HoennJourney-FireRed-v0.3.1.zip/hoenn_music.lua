-- Private song IDs keep Emerald music out of FireRed's ROM song namespace.
return function(mod,world)
 local Audio=require('src.core.game3.audio')
 local songs={};for _,m in pairs(world.maps)do songs[20000+m.music]=m.music end
 local source,active
 local function stop()if source then source:stop();source:release();source=nil end;active=nil end
 local play=Audio.playSong
 Audio.playSong=function(id,opts)
  id=tonumber(id)or id
  if not songs[id]then stop();return play(id,opts)end
  if source and active==id and not(opts and opts.restart)then return true end
  stop();play(0)
  source=love.audio.newSource(mod.assets:path('music/'..songs[id]..'.ogg'),'stream')
  source:setLooping(true);source:setVolume(Audio._bgmVolume or 1);source:play();active=id
  Audio._currentSong={id=id,loop=true};Audio._bgmPaused=false
  return true
 end
 local pause,resume=Audio.pauseBgm,Audio.resumeBgm
 Audio.pauseBgm=function(...)if source then source:pause()end;return pause(...)end
 Audio.resumeBgm=function(...)local r=resume(...);if source then source:play()end;return r end
 local update=Audio.update
 Audio.update=function(dt)
  update(dt)
  if source then
   source:setVolume((Audio._bgmVolume or 1)*(Audio._duck or 1))
   if Audio._fanfareActive or Audio._bgmPaused then source:pause()elseif not source:isPlaying()then source:play()end
  end
 end
 local endSession=Audio.endSession
 Audio.endSession=function(...)stop();return endSession(...)end
 local stopAll=Audio.stopAll
 Audio.stopAll=function(...)stop();return stopAll(...)end
end
