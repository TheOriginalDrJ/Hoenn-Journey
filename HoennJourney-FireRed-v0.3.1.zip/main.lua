-- Hoenn Journey - FireRed
-- Postgame Birch -> Vermilion ferry -> ROM-extracted Slateport Harbor and City.
return function(mod)
  local Slateport=assert(loadstring(assert(mod:read('slateport.lua'))))()(mod)
  local Map = require("src.core.game3.map")
  local Runtime = require("src.core.game3.runtime")
  local Warp = require("src.core.game3.warp")
  local Field = require("src.core.game3.field")
  local Message = require("src.ui.game3.message")
  local Choice = require("src.ui.game3.choice")
  local Bag = require("src.core.game3.bag")
  local Items = require("src.core.game3.items_data")
  local Flags = require("src.core.game3.scripting.flags")
  local Space = require("src.core.game3.scripting.space")
  local Objects = require("src.core.game3.objects")
  local OwSprites = require("src.core.game3.ow_sprites")
  local BIRCH_GRAPHICS_ID = 10001
  local originalResolveGraphics = Space.resolveObjectGraphicsId
  Space.resolveObjectGraphicsId = function(obj, neighbor)
    if obj and obj.scriptKey == "__HOENN_BIRCH__"
        and tonumber(obj.graphicsId) == BIRCH_GRAPHICS_ID then
      return BIRCH_GRAPHICS_ID
    end
    return originalResolveGraphics(obj, neighbor)
  end
  local birchSprite
  local originalGetDraw = OwSprites.getDraw
  OwSprites.getDraw = function(id)
    if tonumber(id) ~= BIRCH_GRAPHICS_ID then return originalGetDraw(id) end
    if not birchSprite then
      local image = assert(mod.assets:image("assets/birch.png"))
      image:setFilter("nearest", "nearest")
      local w, h = image:getDimensions()
      assert(w == 144 and h == 32, "Invalid Birch sprite sheet")
      birchSprite = {image=image, width=16, height=32, frameCount=9, quads={}}
      for frame=0,8 do
        birchSprite.quads[frame] = love.graphics.newQuad(frame*16, 0, 16, 32, w, h)
      end
    end
    return birchSprite
  end

  local TICKET = "HOENN_FERRY_TICKET"
  local BIRCH_LOCAL_ID = 253
  local SAILOR_LOCAL_ID = 252
  local ARRIVAL_MAP = "FR_HOENN_SLATEPORT_DOCK"
  local stateKey = "hoennJourneyFireRed"
  local gameRef

  local function session(game)
    return (game and game.session) or Runtime.getSession()
  end

  local function state(game)
    local s = session(game)
    if not s then return nil end
    s.meta = s.meta or {}
    s.meta[stateKey] = s.meta[stateKey] or s[stateKey] or {}
    return s.meta[stateKey]
  end

  local function cleared()
    return Flags.getFlag(Space.store, nil, "FLAG_SYS_GAME_CLEAR")
      or Flags.getFlag(Space.store, nil, "FLAG_DEFEATED_CHAMP")
  end

  local function isLab(id)
    return id == "FR_OAKS_LAB" or id == "PalletTown_ProfessorOaksLab"
  end

  local function isVermilion(id) return id=='FR_VERMILION_CITY' or id=='VermilionCity' end
  local function sailorDefinitions(defs)
    local out={}
    for _,o in ipairs(defs or {})do
      if o.scriptKey~='__HOENN_SAILOR__'then
        if tonumber(o.localId or o.index)==SAILOR_LOCAL_ID then
          mod.log:warn('Hoenn sailor local ID occupied');return defs
        end
        out[#out+1]=o
      end
    end
    out[#out+1]={localId=SAILOR_LOCAL_ID,x=23,y=32,elevation=3,graphicsId=62,
      movementType=7,facing='up',scriptKey='__HOENN_SAILOR__',passable=false}
    return out
  end

  local function isDock(id)
    id = tostring(id or ""):upper()
    return id:find("VERMILION", 1, true) and id:find("DOCK", 1, true)
      or (id:find("ANNE", 1, true) and id:find("EXTERIOR", 1, true))
  end

  local function copyDef(def)
    local out = {}
    for k, v in pairs(def) do out[k] = v end
    out.objects = {}
    for _, object in ipairs(def.objects or {}) do
      local row = {}; for k, v in pairs(object) do row[k] = v end
      out.objects[#out.objects + 1] = row
    end
    return out
  end

  local function birchDefinitions(defs)
    local out = {}
    for _, object in ipairs(defs or {}) do
      if object.scriptKey ~= "__HOENN_BIRCH__" then
        out[#out + 1] = object
        if tonumber(object.localId or object.index) == BIRCH_LOCAL_ID then
          mod.log:warn("Birch local ID 253 is already occupied; skipping spawn")
          return defs
        end
      end
    end
    if not cleared() then return out end
    local oak
    for _, object in ipairs(out) do
      if tonumber(object.graphicsId or object.graphics) == 71 then oak = object; break end
    end
    if not oak then
      mod.log:warn("Cannot place Birch: Oak's lab object was not found")
      return out
    end
    out[#out + 1] = {
      localId = BIRCH_LOCAL_ID, x = oak.x + 1, y = oak.y,
      elevation = oak.elevation, graphicsId = BIRCH_GRAPHICS_ID,
      movementType = 0x08, facing = "down", scriptKey = "__HOENN_BIRCH__",
      passable = false,
    }
    return out
  end

  local function findDockSource(game)
    for id, def in pairs((game.data and game.data.maps) or {}) do
      if isDock(id) and def then return id, def end
    end
    return nil
  end

  local function ensureArrivalMap(game)
    Slateport.install(game)
    return game.data.maps[ARRIVAL_MAP]
  end

  local function say(text, done)
    Field.lock()
    Message.show(text, function()
      Field.unlock()
      if done then done() end
    end)
  end

  local function giveTicket(game)
    local s, st = session(game), state(game)
    if not (s and st) then return end
    s.bag = s.bag or Bag.new()
    if not Bag.has(s.bag, TICKET, 1) then
      local ok = Bag.add(s.bag, TICKET, 1)
      if not ok then
        say("Your KEY ITEMS pocket is full. Make room, then speak to Birch again.")
        return
      end
    end
    st.ticketGiven = true
    say("You received the HOENN FERRY TICKET!\nBoard at Vermilion's dock.")
  end

  local function talkBirch(game)
    local st = state(game)
    if not cleared() then return false end
    if not st or not st.ticketGiven then
      say("I'm Professor Birch from Hoenn. Oak told me about your League victory!\nA new journey awaits across the sea.", function()
        say("Please accept this ticket for the ferry to Slateport City.", function() giveTicket(game) end)
      end)
    else
      say("Slateport's ferry is ready at Vermilion Dock. Show the crew your ticket.")
    end
    return true
  end

  local function sailToHoenn(game)
    local def, err = ensureArrivalMap(game)
    if not def then say("The Hoenn route is not ready: " .. tostring(err)); return end
    say("Destination: HOENN - Slateport City.\nAll aboard!", function()
      local st=state(game)
      st.returnMap=Map.current
      local ok, warpErr = Warp.request(nil, game, ARRIVAL_MAP, 8, 12, "down")
      if not ok then say("The ferry could not depart: " .. tostring(warpErr)) end
    end)
  end

  local function talkDock(game)
    local s = session(game)
    if not (s and s.bag and Bag.has(s.bag, TICKET, 1)) then
      say('You still have much to learn on your journey.')
      return true
    end
    Field.lock()
    Choice.multi({ "Hoenn", "Cancel" }, 0, function(index)
      Field.unlock()
      if tonumber(index) == 0 then sailToHoenn(game) end
    end, { left = 12, top = 2 })
    return true
  end

  -- Custom items are safe string IDs; mirror the MP3 mod's item-data seam.
  local originalInfo = Items.info
  Items.info = function(id)
    if id == TICKET then
      return { id = TICKET, name = "Hoenn Ferry Ticket", pocket = "KEY_ITEMS",
        fieldUse = "none", price = 0, importance = 1, registrability = 0,
        battleUsage = 0, description = "A ticket for the ferry to Hoenn." }
    end
    return originalInfo(id)
  end

  -- Map.load activates the saved flag store before Objects.loadMap, which
  -- prefers bundle events over mapDef.objects. Supply a temporary bundle
  -- entry during spawning; never leave Birch in shared ROM templates.
  local originalLoadObjects = Objects.loadMap
  Objects.loadMap = function(game, id, def)
    gameRef = game or gameRef
    if not isLab(id) and not isVermilion(id) then return originalLoadObjects(game, id, def) end
    local events = Space.bundle and Space.bundle.events
    local entry = events and events[id]
    local defs = entry and (entry.objects or entry.objectEvents)
      or (def and def.objects) or {}
    local copied = {}; for k, v in pairs(def or {}) do copied[k] = v end
    copied.objects = isLab(id) and birchDefinitions(defs) or sailorDefinitions(defs)
    if entry then
      local temporary = {}; for k, v in pairs(entry) do temporary[k] = v end
      temporary.objects = copied.objects
      events[id] = temporary
    end
    local ok, result = pcall(originalLoadObjects, game, id, copied)
    if entry then events[id] = entry end
    if not ok then error(result, 0) end
    return result
  end

  local originalLoad=Map.load
  Map.load=function(owner,game,id,opts)
    Slateport.install(game)
    return originalLoad(owner,game,id,opts)
  end

  local Overworld = require("src.world.OverworldController")
  local originalTalkTo = Overworld.talkTo
  Overworld.talkTo = function(ow, npc)
    local game = Runtime._game or gameRef
    local mapId = Map.current or (session(game) and session(game).map)
    if isLab(mapId) and npc and tonumber(npc.localId) == BIRCH_LOCAL_ID then
      return talkBirch(game)
    end
    -- The dock's existing sailor is used, preserving the player's requested
    -- flow without guessing a map coordinate or replacing dock scripts.
    if mapId==ARRIVAL_MAP and npc and npc.def.scriptKey=='__HOENN_RETURN__' then
      say('The next ferry returns to Vermilion. Would you like to board?',function()
        Field.lock();Choice.multi({'Vermilion','Cancel'},0,function(i)
          Field.unlock()
          if i==0 then
            local st=state(game)
            local ok,err=Warp.request(nil,game,st.returnMap or 'FR_VERMILION_CITY',23,31,'up')
            if not ok then say('The ferry could not depart: '..tostring(err))end
          end
        end)
      end)
      return true
    end
    if isVermilion(mapId) and npc and npc.def.scriptKey=='__HOENN_SAILOR__' then
      Objects.facePlayer(npc.localId,game)
      return talkDock(game)
    end
    return originalTalkTo(ow, npc)
  end

  mod.log:info("Hoenn Journey 0.3.1: Slateport, Route 110 and Start-menu WARP installed")
end
